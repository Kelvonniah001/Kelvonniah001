cv: function () {
  const filePath = "./cv.pdf";

  const link = document.createElement("a");
  link.href = filePath;
  link.download = "Kelvin_Kyuma_CV.pdf";

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  return "Downloading CV... 📄";
}