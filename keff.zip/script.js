const input = document.getElementById("commandInput");
const output = document.getElementById("output");

// 🌐 Your real projects (edit these links anytime)
const projectLinks = {
  farmeasy: "https://your-farmeasy-link.com",
  portfolio: "https://your-portfolio-link.com",
  dataSystem: "https://your-data-project-link.com"
};
const bootLines = [
  "Booting KelvinOS v1.0...",
  "Loading kernel modules...",
  "Initializing AI subsystem...",
  "Mounting portfolio drive...",
  "Starting terminal interface...",
  "Access granted ✔"
];

let bootIndex = 0;
function bootSystem() {
  if (bootIndex < bootLines.length) {
    print(bootLines[bootIndex]);
    bootIndex++;
    setTimeout(bootSystem, 700);
  } else {
    print("\nWelcome to Kelvin Terminal OS 🤖");
    print("Type 'help' to begin");
  }
}

bootSystem();

// 📄 CV download file (put cv.pdf in same folder)
const cvFile = "cv.pdf";

// 🤖 Simple AI chatbot responses
function aiBot(message) {
  const msg = message.toLowerCase();

  if (msg.includes("hello") || msg.includes("hi")) {
    return "Hello 👋 I'm Kelvin's AI assistant.";
  }

  if (msg.includes("who are you")) {
    return "I'm a terminal AI chatbot inside Kelvin Kyuma's portfolio.";
  }

  if (msg.includes("skills")) {
    return "Kelvin knows HTML, CSS, JavaScript, Node.js, MySQL.";
  }

  if (msg.includes("project")) {
    return "Projects include FarmEasy and data systems.";
  }

  if (msg.includes("kelvin")) {
    return "Kelvin is a Computer Science graduate and developer.";
  }

  return "🤖 I didn't understand that. Try: skills, projects, or about Kelvin.";
}


const commands = {
  help: `
Available commands:
- about
- skills
- projects
- contact
- cv
- chat [message]
- clear
  `,

  about: `
Hi, I'm Kelvin Kyuma.
Computer Science graduate passionate about:
- Web Development
- Data Systems
- Backend Engineering
  `,

  skills: `
Skills:
- HTML, CSS, JavaScript
- Node.js
- MySQL
- PHP (basic)
- Data Entry & Analysis
  `,

  projects: `
Projects:
1. FarmEasy E-commerce → ${projectLinks.farmeasy}
2. Data System Project → ${projectLinks.dataSystem}
3. Portfolio Terminal → ${projectLinks.portfolio}
  `,

  contact: `
Email: kevoannebelle@gmail.com
Phone: 0748751121
Location: Nairobi, Kenya
  `,

 cv: function () {
  const filePath = "./cv.pdf";

  const link = document.createElement("a");
  link.href = filePath;
  link.download = "Kelvin_Kyuma_CV.pdf";

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  return "Downloading CV... 📄";
}
};

function print(text) {
  output.innerText += "\n" + text + "\n";
}

input.addEventListener("keydown", function (e) {
  if (e.key === "Enter") {
    const cmd = input.value.trim();

    print(`guest@portfolio:~$ ${cmd}`);

    // CLEAR
    if (cmd === "clear") {
      output.innerText = "";
    }

    // CV DOWNLOAD
    else if (cmd === "cv") {
      print(commands.cv());
    }

    // AI CHATBOT COMMAND
   else if (cmd.toLowerCase().startsWith("chat ")) {
  const message = cmd.substring(5).trim();
  
  if (message.length === 0) {
    print("AI: Please type a message after 'chat'");
  } else {
    const response = aiBot(message);
    print("AI: " + response);
  }

    }

    // NORMAL COMMANDS
    else if (commands[cmd]) {
      print(commands[cmd]);
    }

    // UNKNOWN
    else {
      print("Command not found. Type 'help'.");
    }

    input.value = "";
  }
});

// Welcome message
print("Welcome to Kelvin Terminal Portfolio 🤖");
print("Type 'help' to begin");