const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const app = express();
app.use(cors());
app.use(express.json());

const SECRET = "farmEasySecretKey";

// Fake DB (replace with MySQL later)
let users = [
    {
        id: 1,
        username: "admin",
        password: bcrypt.hashSync("1234", 8),
        role: "admin"
    }
];

// 🔐 LOGIN
app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    const user = users.find(u => u.username === username);
    if (!user) return res.status(404).json({ message: "User not found" });

    const valid = bcrypt.compareSync(password, user.password);
    if (!valid) return res.status(401).json({ message: "Invalid password" });

    const token = jwt.sign({ id: user.id, role: user.role }, SECRET, { expiresIn: "1h" });

    res.json({ token, role: user.role });
});

// 🔒 Middleware
function verifyToken(req, res, next) {
    const token = req.headers["authorization"];
    if (!token) return res.status(403).json({ message: "No token provided" });

    jwt.verify(token, SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ message: "Unauthorized" });
        req.user = decoded;
        next();
    });
}

// 👨‍💼 ADMIN ONLY
app.get("/api/admin/stats", verifyToken, (req, res) => {
    if (req.user.role !== "admin") {
        return res.status(403).json({ message: "Admins only" });
    }

    res.json({
        users: 120,
        orders: 45,
        revenue: "KES 75,000"
    });
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));